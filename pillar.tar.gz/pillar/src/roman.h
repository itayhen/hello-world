#ifndef ROMAN_H__
#define ROMAN_H__

#include <stdlib.h>
#include <string.h>

#define ROMAN_MAX_NUM_SIZE 100  // Max size of one string

// calc_roamn is the main function. 
// Input Roman mat expression
// Output the result of the expression 
char* clac_roman(const char *str_in);

int split_str_in_to_num_command(const char *str_in, char *str1, char *str2, char *command);


int get_int_from_roman(const char *str);

#endif
