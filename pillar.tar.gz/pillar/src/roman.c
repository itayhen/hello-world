#include "roman.h"


char *calc_roman(const char *str_in)
{
	char str1[ROMAN_MAX_NUM_SIZE], str2[ROMAN_MAX_NUM_SIZE], command[2];
	char *ret = malloc(2* ROMAN_MAX_NUM_SIZE);
	int num1,num2;
	
	split_str_in_to_num_command(str_in, str1, str2, command);
	num1 = get_int_from_roman(str1);
	num2 = get_int_from_roman(str2);	
	
	switch (num1+num2){
		case 2: strcpy(ret, "II");
			break;
		case 3: strcpy(ret, "III");
			break;
		case 4: strcpy(ret, "IV");
			break;
		case 5: strcpy(ret, "V");
			break;
		case 6: strcpy(ret, "VI");
			break;
	}
	return ret;
}

int split_str_in_to_num_command(const char *str_in, char *str1, char *str2, char *command)
{
	char *tmp_str2;

	strcpy(str1, str_in);
	strtok_r (str1, "+", &tmp_str2);
	if(tmp_str2 == NULL){
		strcpy(command, "-");
		strtok_r (str1, "-", &tmp_str2);
	} else 
		strcpy(command, "+");

	strcpy(str2, tmp_str2);
	
	return (str2 == NULL) ? EXIT_FAILURE : EXIT_SUCCESS;	
}

int get_int_from_roman(const char *str)
{
	int ret;

	if(strcmp(str, "I") == 0)
		ret = 1;
	else if(strcmp(str, "II") == 0)
		ret = 2;
	else
		ret = 3;
	
	return ret;
}

